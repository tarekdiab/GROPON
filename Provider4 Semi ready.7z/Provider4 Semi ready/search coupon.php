
<!DOCTYPE html >
<html >

<head>

    
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <title> صـفحة المزود </title>



  <link rel="stylesheet" type="text/css" href="css/style_login.css" />
  <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
      
<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Core CSS RTL-->
    <link href="css/bootstrap-rtl.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/sb-admin-rtl.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
  <?php  
	include('./classes/ClsCoupons.php');
	$obj_dbOpr=new Coupon_Object();

       
	?>

</head>




<body >

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <img src="images/4.PNG"  width="200" height="230"  class="img-responsive" alt=""/>
            </div>
            <!-- Top Menu Items -->
            
           <ul class="nav top-nav navbar-right" style="margin-right: 1000px">

                <li class="dropdown nav-item">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"> طارق ذياب  <i class="fa fa-user"></i><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-user"></i> الصفحة الرئيسية</a>
                        </li>
                        
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-gear"></i> الإعدادات</a>
                        </li>
                        <li class="divider"></li>
                        
                         <li class="divider"></li>
                        <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> تسجيل الخروج </a>
                        </li>
                    </ul>
                </li>
            <ul class="nav top-nav navbar-right">
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
                
            </ul>
            
            
          
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><h4><i class="fa fa-fw fa-dashboard"></i> الصفحة الرئيسية </h4></a>
                    </li>
                    <li>
                        <a href="search coupon.php"><h4><i  class="fa fa-fw fa-search"></i>  البحث عن كوبون </h4></a>
                    </li>
                    <li>
                        <a href="upload product.php"><h4><i  class="fa fa-fw fa-upload"></i> إضافة المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit product.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit dis.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة تخفيضات </h4> </a>
                    </li>
                    
                    <li>
                        <a href="add edv.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة أعلانات  </h4> </a>
                    </li>
                    <li>
                        <a href="add Account.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة محاسب   </h4> </a>
                    </li>
                    <li>
                        <a href="add Account.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل الحساب  </h4></a>
                    </li>
                    
                  
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <br />    <br />   <br />    <br />
                <div class="row">
                    <div class="col-lg-12">
                        <h1 style="color: #df8a13 ; padding-top: 10px" class="page-header">
                            البحث عن كوبون 
                        </h1>
                    </div>
                </div>
                <br /> 
                
                
                 <div class="col-sm-12">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <h3 class="panel-title"><div class="card-header card-default">
                                <i class="fa fa-fw fa-search"></i>  أبحث عن الكوبون
                            </div></h3>
                            </div>
                            <div class="panel-body">
                            
                            <h5> <p style="text-align: center;">  البحث عن الكوبون  </p></h5>
                            
                            <form  method="post">
                            <div class="form-group input-group">
                                <span class="input-group-btn"><input type="submit"  name="btnSubmit" class="btn btn-default" /><i class="fa fa-search"></i></span>
                                <input type="text"  name="txtCriterion" class="form-control" placeholder=" أدخـــــــــــــــــــــــــــــــــــــــــــــــل الكوبـــــــــــــــــــــــــــــــــــــــــــــــــــــــــون هنـــــــــــــــــــــــــــــــــــــــــــــــــا  "/>
                                
                            </div>
                            </div>
                            
                            
                            
                             <?php
                        
                      if(@$_POST['btnSubmit'])
             	       {
	                  $Criterion=$_POST['txtCriterion'];
      
               $res= $obj_dbOpr->search_for_coupons($Criterion);
              if($res)
               {
				  echo "<script> alert('Product was inserted sucessfully');</script>";
           
            ?>
            <div class="row">
 
                    <div class="col-lg-12">
                    
                    
                        <h2> أستعلام الكوبون </h2>
                        <br />
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" dir="rtl">
                            
                               
								
								
								
                                    <tr>
                                    <th></th>
                                        <th>Coupon_No</th>
                                        <th>coupon_validation</th>
                                        <th> State</th>
                                        <th>user_name</th>
                                        
                                            <th>Phone_number</th>
                                              <th>Product Name</th>
                                                <th>prd_price</th>
                                                  <th>discount_name</th>
                                                    <th>disc_qty</th>
                                                      <th>no_disc_pieces</th>
                                                      <th>disc_kind</th>
                                    </tr>
                               
                                <tbody>
                                
								
								
								
								 
                                    <?php   while($data=mysql_fetch_array($res)){ ?>
                                    
                                     <tr>
                 
                        
                  <td><div class="col-lg-4">
                                        <img src="Shaker/1033.png" style="border: 5px solid #555555; height: 100px; width: 150px ; "/>
               
                                        <td><?php echo $data[0]; ?></td>
                                        <td><?php echo $data[1]; ?></td>
                                        <td><?php echo $data[2]; ?></td>
                                        <td><?php echo $data[3];?></td>
										 
                                        <td><?php echo $data[4]; ?></td>
                                        <td><?php echo $data[5]; ?></td>
                                        <td><?php echo $data[6]; ?></td>
                                        <td><?php echo $data[7]; ?></td>
                                        <td><?php echo $data[8]; ?></td>
                                        <td><?php echo $data[9]; ?></td>
                                        <td><?php echo $data[10]; ?></td>
                                        

                                         </div></td>
                                    </tr>
                                   <?php } ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                                
                            </div>
                        </div>
                        
               
                    </div>
                                                                
                
                <!-- /.row -->
                 <?php
		   
		   
		           }
           else
             {  echo "<script> alert('Error');</script>";}

              }
                 
                 ?>
                            </form>

                                      
                                
                <!-- /.row -->
                

<br /> <br /> 


 
                  <!-- /.row -->
                  
                    
                       
                
                 <br/> <br/> <br/> 

                
                     <!-- /.row -->
                     
                   

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    
    
   

  <script type="text/javascript">
	$("#modal_trigger").leanModal({top : 200, overlay : 0.6, closeButton: ".modal_close" });

	$(function(){
		// Calling Login Form
		$("#login_form").click(function(){
			$(".social_login").hide();
			$(".user_login").show();
			return false;
		});

		// Calling Register Form
		$("#register_form").click(function(){
			$(".social_login").hide();
			$(".user_register").show();
			$(".header_title").text('Register');
			return false;
		});

		// Going back to Social Forms
		$(".back_btn").click(function(){
			$(".user_login").hide();
			$(".user_register").hide();
			$(".social_login").show();
			$(".header_title").text('Login');
			return false;
		});

	})
</script>




 <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>
</body>

</html>
