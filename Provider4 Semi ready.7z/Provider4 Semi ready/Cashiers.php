<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
 <script type="text/javascript" src="//code.jquery.com/jquery-latest.js"></script>
    <title> صـفحة المزود </title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Core CSS RTL-->
    <link href="css/bootstrap-rtl.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/sb-admin-rtl.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    
    
    
    
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		 
		
		<link rel="stylesheet" type="text/css" href="css/PopupStyle.css" />
		<script src="js/modernizr.custom.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php
  error_reporting(E_ALL ^ E_NOTICE); 
	include('./classes/ClsProducts.php');
	$obj_dbOpr=new Product_Object();
	 include('./classes/ClsDiscounts.php');
	
	$obj_disc=new Discount_Object();
	$prodcuts;
	$prdID;
	if(@$_GET['id'])
	{
	    
	      $prdID=$_GET['id'];
	     $prodcuts=$obj_dbOpr->retrieve_selected_prd_data($prdID)  ;   	        
	        
		//if(mysql_num_rows($prodcuts))
		 //echo "<script language='javascript' type='text/javascript'> alert(' Done');</script>  ";
	
    }
	else
	{
       
	   
	    $prodcuts=$obj_dbOpr->showAllProducts(1);
	}
        
		
		
    if(@$_POST['sumit'])
	{
	    $Discname=$_POST['Discount_name'];
       	$DiscQuant=$_POST['disc_qty'];
        $PiecesCountPerDisc=$_POST['no_disc_pieces'];
        $Disc_kind=$_POST['disc_kind'];
        
       
		$res=$obj_disc->insert_into_discount($Discname,$DiscQuant,$PiecesCountPerDisc,$prdID,$Disc_kind,1);
	 if($res)
           {echo "Product was inserted sucessfully";}
           else
           {echo "Wrong";}
	          	        
	        
		
		
	
    }
       
    	
    	
    	
		
	?>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
              <img src="images/4.PNG"  width="200" height="230"  class="img-responsive" alt=""/>
            </div>
            <!-- Top Menu Items -->
            
            <ul class="nav top-nav navbar-right" style="margin-right: 1000px">

                <li class="dropdown nav-item">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"> طارق ذياب  <i class="fa fa-user"></i><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-user"></i> الصفحة الرئيسية</a>
                        </li>
                        
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-gear"></i> الإعدادات</a>
                        </li>
                        <li class="divider"></li>
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-power-off"></i>تسجيل الخروج</a>
                        </li>
                    </ul>
                </li>
            <ul class="nav top-nav navbar-right">
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
              
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><h4><i class="fa fa-fw fa-dashboard"></i> الصفحة الرئيسية </h4></a>
                    </li>
                    <li>
                        <a href="search coupon.php"><h4><i  class="fa fa-fw fa-search"></i>  البحث عن كوبون </h4></a>
                    </li>
                    <li>
                        <a href="upload product.php"><h4><i  class="fa fa-fw fa-upload"></i> إضافة المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit product.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit dis.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة تخفيضات </h4> </a>
                    </li>
                    
                    <li>
                        <a href="add edv.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة أعلانات  </h4> </a>
                    </li>
                    <li>
                        <a href="add Account.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة محاسب   </h4> </a>
                    </li>
                    <li>
                        <a href="add Account.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل الحساب  </h4></a>
                    </li>
                    
                    <li>
                
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
<!-- Register Form -->
			<div class="user_register">
				<form method="post">
					<label>الاسم الكامل</label>
					<input type="text"  name="userName"/>
					<br />

					<label>البريد الالكتروني</label>
                    
					<input type="email"  placeholder="وصــف المنتج" name="userEmail"/>
					<br />

					<label>كلمة المرور</label>
					<input type="password" name="userPwd" />
					<br />
					<label>رقم التلفون</label>
					<input type="tel"  name="userNumber"/>
					<br />
					<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                                Launch Demo Modal
                            </button>

					
					<div class="action_btns">
						<div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> السابق</a></div>
						<div class="one_half last"><a href="#" class="btn btn_red" onclick="$(this).closest('form').submit();">تسجيل</a></div>
					</div>
				</form>
			</div>
    

</body>

</html>





