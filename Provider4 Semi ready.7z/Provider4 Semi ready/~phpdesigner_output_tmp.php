<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
 <script type="text/javascript" src="//code.jquery.com/jquery-latest.js"></script>
    <title> صـفحة المزود </title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Core CSS RTL-->
    <link href="css/bootstrap-rtl.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/sb-admin-rtl.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
 <?php 

	include('./classes/ClsProducts.php');
	$obj_dbOpr=new Product_Object();
	if(@$_POST['sumit'])
	{
	    $prdname=$_POST['prd_name'];
       	$prdPrice=$_POST['prd_price'];
        $prdQty=$_POST['prd_quantity'];
        $prdtype=$_POST['prd_type'];
       // $obj_dbOpr->prd_Image=str_replace("'","''",$_POST['prd_img']);
        $Prd_desc=$_POST['prd_desc'];
        
        $res= $obj_dbOpr->insert_prd($prdname,$prdtype,$prdPrice,$prdQty,$Prd_desc,1);
        if($res)
           {echo "<script> alert(Product was inserted sucessfully);</script>";}
           else
           {echo "<script> alert(Error);</script>";}
        
	
		
	
    }
       
	
	
	
	
	
	?>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <a class="navbar-brand" href="index-rtl.html"> يـــمن بون </a>
            </div>
            <!-- Top Menu Items -->
            
            <ul class="nav navbar-nav top-nav navbar-right pull-xs-right" style="margin-right: 1200px">

                <li class="dropdown nav-item">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"> طارق ذياب  <i class="fa fa-user"></i><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-user"></i> الصفحة الرئيسية</a>
                        </li>
                        
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-gear"></i> الإعدادات</a>
                        </li>
                        <li class="divider"></li>
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-power-off"></i>تسجيل الخروج</a>
                        </li>
                    </ul>
                </li>
            <ul class="nav navbar-right top-nav">
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
              
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index-rtl.html"><i class="fa fa-fw fa-dashboard"></i> الصفحة الرئيسية </a>
                    </li>
                    <li>
                        <a href="search coupon.php"><i  class="fa fa-fw fa-search"></i>  البحث عن كوبون </a>
                    </li>
                    <li>
                        <a href="upload product.php"><i  class="fa fa-fw fa-upload"></i> أضافة المنتجات </a>
                    </li>
                    <li>
                        <a href="edit product.php"><i class="fa fa-fw fa-edit"></i> تعديل المنتجات  </a>
                    </li>
                    <li>
                        <a href="edit dis.php"><i class="fa fa-fw fa-upload"></i> أضافة تخفيضات  </a>
                    </li>
                    <li>
                        <i class="fa fa-fw fa-edit"></i> تعديل الحساب </a>
                    </li>
                    
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-arrows-v"></i> Dropdown <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                        </ul>
                    </li>
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                
                
                                                                
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            أضافة المنتجات 
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
<br /><br />
<div class="col-sm-12">

                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><div class="card-header card-default">
                                <i class="fa fa-upload fa-fw"></i> أضافة المنتجات 
                            </div></h3>
                            </div>
                            <div class="panel-body">
                             
                          
                <div class="row">
                    <div class="col-xl-4 col-lg-12">
                        <div class="card card-default">
                            
                            <div class="card-block">
                               <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               
                    <div class="col-md-4 col-sm-4 col-xs-4">
                        
                  <div class="clearfix"></div>
                    <div class="x_content">
                         <br />
                          <br />
               
            

                 <h5> <p style="text-align: center;">قم بأضافة المنتجات الخاصة بك هنا </p></h5>
                         <br />
                 
                
                  
                  <input type ="file" class="dropzone" style="border: 5px solid #555555; height: 380px; width: 350px ; " name="img_pic"/>
                  
             
            
                  

                </div>
                </div>
                

                              
                        <!-- Cropping modal -->
                       

                   <div class="col-md-3 col-sm-3 col-xs-3">
                    
                  <div class="clearfix"></div>
                 
                    <div class="x_content">
                    
                    

                         <br />
                  <br />

                 <h5> <p style="text-align: center;">معلومات المنتج</p></h5>

                </div>
                
                  <br />
                    <form    method="post"  class="my-form" >
                  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="form-input"><input type="text" placeholder="إســـم المنتج "  name="prd_name"  class="form-control"></div>
                <br />
               <div class="form-input"><input type="Number" placeholder=" الكمية المتوفرة من المنتج ( العدد ) " name="prd_quantity" class="form-control" ></div>
                <br />
                <div class="form-input"><input type="Number" placeholder=" سعر المنتج " class="form-control" name="prd_price"></div>
                 <br />
              <!-- <br />
                <div class="form-input"><input type="File" name="prd_img"  class="form-control" /></div>
                 <br /> -->
                 <div class="form-input"> 
                 
                   <select name="prd_type"  >
                    					
						   <option> Clothing </option>
						   <option> Food</option>
						   <option> Electronics</option>
					
                    </select>
                    
                    
                   </div>
                
            
               
                 <br /> 
                   <textarea class="form-control" rows="3" placeholder='وصــف المنتج' name="prd_desc"></textarea>
                   <br />
                </div>
               
                <div class="col-md-1 col-sm-1 col-xs-1">
                         <input type="submit" class="btn btn-primary" style="margin-left: 90px " name="sumit" />    
                          </div>  
                     
                       
                <button type="button" class="btn btn-danger" style="margin-right: 90px">إلغاء ألأمــر </button>
           
              <br />
               <br />
                  
                 </form>
                     
               
                                                                                     
                                                                        
                </div>
                
                <br />
                                                            
                  <div class="col-md-3 col-sm-3 col-xs-3">
                    
                  <div class="clearfix"></div>
                 
                    <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                     <div class="form-group">
                     <br /> <br /> <br /> <br />
                  <!--   <div class="col-md-3 col-sm-3 col-xs-3">
                                <label><h5> المقاسات</h5> </label>
                                	<div class="checkbox">
								<ul>       
								<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>S</label></li>
									<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>M</label></li>
									<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>L</label></li>
									<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>XL</label></li>
								</ul>
							</div>
                            </div>
                            -->
                           	<h5> مقدار  التخفيض :</h5>
                           
   <input type="radio" name="gender" value="male" checked="" > لايوجد <br>
   <input type="radio" name="gender" value="male"> 50 %<br>
  <input type="radio" name="gender" value="female"> 40 % <br>
  <input type="radio" name="gender" value="male"> 30 %<br>
  <input type="radio" name="gender" value="female"> 20 % <br>
  <input type="radio" name="gender" value="other"> 10 %
  
                            
                           </div>
                       						
		
                            
                            
                            
                            
                            <div class="item-box">
    <div>
	Color :
    <select name="product_color">
    <option value="Red">Red</option>
    <option value="Blue">Blue</option>
    <option value="Orange">Orange</option>
    </select>
	</div>
	
	<div>
    Qty :
    <select name="product_qty">
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    </select>
	</div>
	
	<div>
    Size :
    <select name="product_size">
    <option value="">S</option>
    <option value="">M</option>
	<option value="">L</option>
    <option value="">XL</option>
    <option value="">XLL</option>
    </select>
	</div>
                               
                            </div>
                            </div>
                             </div>
                            </div>
                                            
              </div>
                            
                    </div>  
                                
                            </div>
                        </div>
                    </div>
                </div>
                
                             
                             
                            </div>
                        </div>
                    </div>
                <br/>
                 <br/>
                  
                     
                                
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    
    <script type="text/javascript">
    jQuery(document).ready(function($){
        $('.my-form .add-box').click(function(){
            var n = $('.text-box').length +1;
            if( 8 < n ) {
                alert('Stop it!');
                return false;
            }
            var box_html = $('<p class="text-box"><label for="Properties' + n + '">الخاصية</label><span> <input type="text" name="Properties[]" value="" id="box' + n + '" /> <label for="Qty_available' + n + '">الكمية المتوفرة   </span><input type="text" name="Qty_available[]" value=""  />  <a href="#" class="remove-box">Remove</a></p>');
            box_html.hide();
            $('.my-form p.text-box:last').after(box_html);
            box_html.fadeIn('slow');
            return false;
        });
        $('.my-form').on('click', '.remove-box', function(){
            $(this).parent().css( 'background-color', '#FF6C6C' );
            $(this).parent().fadeOut("slow", function() {
                $(this).remove();
                $('.box-number').each(function(index){
                    $(this).text( index + 1 );
                });
            });
            return false;
        });
    });
    </script>
  
<script src="js/dropzone/dropzone.js"></script>
   
  
  
    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

    <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>  
    
    
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    

</body>

</html>
