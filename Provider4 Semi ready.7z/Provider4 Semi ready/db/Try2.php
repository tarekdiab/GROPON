<!DOCTYPE html>
    <html>
    <head>
   
    <title>Add or Remove text boxes with jQuery</title>
    <script type="text/javascript" src="//code.jquery.com/jquery-latest.js"></script>
   
    
    
    
    
    
    
    
    
    
    
    
     <?php   
   

//please assume boxes = training

if(@$_POST['Sumit'])
    {$i = 0; 
  foreach($_POST['boxes'] as $textbox){
     $training= $textbox;
    // $amount = $_POST['amount'][$i];
     echo "<script language='javascript' type='text/javascript'> alert('$training');</script>  ";
    }
   
}

    ?>
    </head>
    <body>
    <div id="main">
        <h1>Add or Remove text boxes with jQuery</h1>
      
            <form role="form" method="post" action="Try2.php"  class="my-form">
                  <label for="box1"><span class="namer">Name</span></label>
                   <input type="text" name="name" />
                <p class="text-box">
                    <label for="box1">Box <span class="box-number">1</span></label>
                    <input type="text" name="boxes[]" value="" id="box1" />
                    <a class="add-box" href="#">Add More</a>
                </p>
                
                <p class="Avaialables">
                    <label for="avail1">Avail <span class="avail-number">1</span></label>
                    <input type="text" name="avails[]" value="" id="avail1" />
                     <input type="text" name="qnt[]" value=""  />
                    <a class="add-avail" href="#">Add avail</a>
                </p>
                <p><input type="submit" name="Sumit" /></p>
            </form>
      
    </div>
    <script type="text/javascript">
      
      jQuery(document).ready(function($){
    
        $('.my-form .add-box').click(function(){
            var n = $('.text-box').length + 1;
            if( 5 < n ) {
                alert('Stop it!');
                return false;
            }
            var box_html = $('<p class="text-box"><label for="box' + n + '">Box <span class="box-number">' + n + '</span></label> <input type="text" name="boxes[]" value="" id="box' + n + '" /><label for="box' + n + '">Box <span class="box-number">' + n + '</span></label> <input type="text" name="boxw[]" value="" id="box' + n + '" /> <a href="#" class="remove-box">Remove</a> <a href="#" class="Addbx">Add </a></p>');
            box_html.hide();
            $('.my-form p.text-box:last').after(box_html);
            box_html.fadeIn('slow');
            return false;
        });
        $('.my-form').on('click', '.remove-box', function(){
            $(this).parent().css( 'background-color', '#FF6C6C' );
            $(this).parent().fadeOut("slow", function() {
                $(this).remove();
                $('.box-number').each(function(index){
                    $(this).text( index + 1 );
                });
            });
            return false;
        });
        
       
         $('.my-form .add-avail').click(function(){
            var n = $('.Avaialables').length + 1;
            if( 5 < n ) {
                alert('Stop it!');
                return false;
            }
            
          
          var avail_html = $('<p class="avail-number"><label for="avail' + n + '">Avail <span class="box-number">' + n + '</span></label> <input type="text" name="avails[][]" value="" id="Avail' + n + '" /><label for="box' + n + '">Box <span class="box-number">' + n + '</span></label> <input type="text" name="qnt[][]" value="" id="av' + n + '" /> <a href="#" class="remove-box">Remove</a> <a href="#" class="Addbx">Add </a></p>');
            avail_html.hide();
            $('.my-form p.text-box:last').after(avail_html);
           avail_html.fadeIn('slow');
            return false;
        });
    });
    </script>
    </body>
    </html>



 

    