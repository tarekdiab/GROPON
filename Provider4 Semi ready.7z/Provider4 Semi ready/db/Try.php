<HTML>
<HEAD>


 
<TITLE>Dynamically add Textbox, Radio, Button in html Form using JavaScript</TITLE>
<SCRIPT language="javascript">
function add(type) {
 
    //Create an input type dynamically.
       var txt='A';
   
          
          
        var element = document.createElement("input");
 
    //Assign different attributes to the element.
    element.setAttribute("text", type);
    element.setAttribute("value",txt+2 );
    element.setAttribute("name", txt+1);
 
 
    var foo = document.getElementById("fooBar");
 
    //Append the element in page (in span).
    foo.appendChild(element);
    
     var element = document.createElement("input");
      element.setAttribute("submit", type);
  
    element.setAttribute("name", sumit);
      var foo = document.getElementById("fooBar");
 
    //Append the element in page (in span).
    foo.appendChild(element);
   

 
}
</SCRIPT>


<?php 
         if(@$_GET['sumit'])
           {
			echo "<script language='javascript' type='text/javascript'> alert('ss');</script>  ";
			
		}
 
?>
</HEAD>


<BODY>
<FORM  role="form"  action="Try.php" method="get">
<H2>Dynamically add element in form.</H2>
Select the element and hit Add to add it in form.
<BR/>
<SELECT name="element">
    <OPTION value="button">Button</OPTION>
    <OPTION value="text">Textbox</OPTION>
    <OPTION value="radio">Radio</OPTION>
</SELECT>
 
<INPUT type="button" value="Add" onclick="add(document.forms[0].element.value)"/>
 
<span id="fooBar">&nbsp;</span>
 
</FORM>
</BODY>
</HTML>