<?php
	include('./db/db.php');
	
	
	class DataBase_Opretions
	{
	
		function insert_into_discount($name,$qty,$piecesCount,$discTyp,$prdId)
		{
		 
		   $sql="insert into discounts(discount_name,disc_qty,no_disc_pieces,disc_type_id,prd_id)
			      values('$name','$qty','$piecesCount','$discTyp','$prdId'); ";
            $result=mysql_query($sql);
            
              if($result)
               return true;
            else
            return  false;
			
		}
	   	
		
		
		
	  //Function to store new users
	   	function insert_disc($disc_kind)
		{ 
              	$this->insert_into_img();
		    $sql="insert into products(disc_kind)
			      values('$disc_kind'); ";
            $result=mysql_query($sql);
            if($result)
              if($result)
               return true;
            else
            return  false;
			
			
		}
		
		
		//Select last user from usrs
		
	
		
		//Function to store properties
		
		
	
		
		function show_types()
		{
			 $query="select * from discount_types;";
	
		     $result=mysql_query($query);
           
           return $result;
			
			
		}
		
		function show_products()
		{
			 $query="select * from products ;";
	
		     $result=mysql_query($query);
           
            return $result;
		
			
			
		}
		
		
		
		function retrive_selected_prd_id($field)
		{
			 $query=mysql_query("select prd_id from products where prd_name='$field';");
	
		     $result = mysql_fetch_array($query);
           
            if($result)
               return   $result[0];
             else 
                return 0;
			
			
		}
	
		
	 function retrive_selected_type_id($field)
		{
			 $query=mysql_query("select disc_type_id from discount_types where disc_kind='$field';");
	
		     $result = mysql_fetch_array($query);
           
            if($result)
               return   $result[0];
             else 
                return 0;
			
			
		}
	function show_all_discounts()
	  {
		 $sql="select d.discount_name,d.disc_qty,d.no_disc_pieces,p.prd_name,dt.disc_kind,p.prd_pic,u.user_name
                       from discounts d inner join products p inner join users u inner join  discount_types dt on
                       d.prd_id=p.prd_id and d.disc_type_id =dt.disc_type_id  and u.user_id=p.provider_id	
					      order by  d.discount_id desc" ;
			      
            $result=mysql_query($sql);
            
              return $result;
		
		
	}
	
	   
	      
	   
	    
	 
		
		
	}
?>