<?php
	include('./db/db.php');
	
	
	class DataBase_Opretions
	{
	  function generate_rand()
	  {
	   $a=mt_rand(0,9);
	   for($i=0;$i<11;$i++)
	   $a.=mt_rand(0,9);
	   
	   return $a;
		
		
	  }
	  
		function insert_into_coupons($customer_id,$discount_id)
		{
		   $CouponNum=$this->generate_rand();
		   $sql="insert into coupons(Coupon_No,discount_id,customer_id)
			      values('$CouponNum','$discount_id','$customer_id'); ";
            $result=mysql_query($sql);
            
              if($result)
               return true; 
            else
            return  false;
			
		}
		
  	function insert_into_coupon_desc($coupon_id,$desc_id)
		{
		 
		   $sql="insert into discounts(desc_id,coupon_id)
			      values('$desc_id','$coupon_id'); ";
            $result=mysql_query($sql);
            
              if($result)
               return true;
            else
            return  false;
			
		}
	   	
		
		//Function to store properties
		
		
	
		
		function show_discounts()
		{
			 $query="select * from discounts;";
	
		     $result=mysql_query($query);
           
           return $result;
			
			
		}
		
	
		
		
		function retrive_selected_prd_id($field)
		{
			 $query=mysql_query("select prd_id from products where prd_name= '$field';");
	
		     $result = mysql_fetch_array($query);
           
            if($result)
               return   $result[0];
             else 
                return 0;
			
			
		}
	
		function retrive_selected_disc_id($field)
		{
			 $query=mysql_query("select discount_id from discounts where discount_name= '$field';");
	
		     $result = mysql_fetch_array($query);
           
            if($result)
               return   $result[0];
             else 
                return 0;
			
			
		}
	
			function retrive_selected_customer_id($field)
		{
			  $sql=mysql_query("select customer_id from customers where user_id= $field");
	                  
		           $user_id = mysql_fetch_array($sql);
		           if($user_id)
		            return $user_id[0];
		            else return 0;
			
			
		}
	
		    	
	   function retrive_all_descriptions()
		{
		 
		 $query="SELECT prd.prd_name, p.prop_name, av.avail_branch_name
                                FROM description d
                                INNER JOIN products prd
                                INNER JOIN attributes a
                                INNER JOIN properties p
                                INNER JOIN available av ON d.Prd_id = prd.Prd_id
                                AND d.attr_id = a.attr_id
                                AND a.prop_id = p.prop_id
                                AND a.avail_id = av.avail_id";
	
		   $result =mysql_query($query);
           
           return $result;
		
			
		}       
		
	   function retrive_selected_user_id($field)
		{
		 
		 $query=mysql_query("select user_id from users where user_email= '$field'");
	
		   $result = mysql_fetch_array($query);
           
            if($result)
               { 
			  
		            //$this->retrive_selected_customer_id($result[0]);
		            return $result[0];
			    
			   
			   }
			  else
			   return 0;
			   
            
			
			
		}
		
		
		//Show all coupons or specific coupon
		
		function show_coupons($prvd)
		{
			
			$query="

                select * from 

             (select c.Coupon_No,c.coupon_validation,c.State,u.user_name,u.phone_number,p.prd_name,
              p.prd_price ,d.discount_name,d.disc_qty,d.no_disc_pieces, dt.disc_kind,p.prd_pic,prvd.provider_id
               from coupons c inner join discounts d  inner join discount_types dt
               inner join users u inner join products p  inner join customers cust
               inner join providers prvd
               on d.discount_id=c.discount_id  and d.disc_type_id=dt.	disc_type_id
               and d.prd_id=p.prd_id and  cust.customer_id=c.customer_id and u.user_id=cust.user_id and
           prvd.provider_id=p.provider_id) temp_coup
           where  temp_coup.provider_id=$prvd ";
			$result=mysql_query($query);
			return $result;
			
			
		}
		
		
		
		function search_for_coupons($field,$prvd_id)
		{
			$query="select * from 

             (select c.Coupon_No,c.coupon_validation,c.State,u.user_name,u.phone_number,p.prd_name,
              p.prd_price ,d.discount_name,d.disc_qty,d.no_disc_pieces, dt.disc_kind,p.prd_pic,prvd.provider_id
               from coupons c inner join discounts d  inner join discount_types dt
               inner join users u inner join products p  inner join customers cust
               inner join providers prvd
               on d.discount_id=c.discount_id  and d.disc_type_id=dt.	disc_type_id
               and d.prd_id=p.prd_id and  cust.customer_id=c.customer_id and u.user_id=cust.user_id and
           prvd.provider_id=p.provider_id) temp_coup
           where  temp_coup.provider_id=$prvd_id and (temp_coup.Coupon_No='$field' or  temp_coup.phone_number=$field) ";
			$result=mysql_query($query);
			return $result;
			
			
		}
		
		function retrive_prvd_name($prvd_name)
		 {
			 
			

			 $sql=mysql_query(" select * from
                                  (select u.user_name,u.user_email,p.provider_id
                                     from users u inner join providers p
                                      on p.user_id=u.user_id ) temp_prvd
           
                                    where temp_prvd.user_name='$prvd_name';");
									
					 $rowsCount=mysql_num_rows($sql);
					 if($rowsCount	>0)
					 {  $provider_id=mysql_fetch_row($sql);
					    return $provider_id[2] ;
					 }	
					else
					    return 0;
									
			 
			 
			 
	    }
		
		
		
	
	
	   
	      
	   
	    
	 
		
		
	}
?>