<?php
	include('./db/db.php');
	
	
	class Product_Object
	{
	
	
	
	   
	      
	     var  $prd_Image;
	    
	 
		function insert_into_img()
		{
			if($_FILES["prd_img"])
			{
			 $tempName=$_FILES["prd_img"]["tmp_name"];
			 $orgName=$_FILES["prd_img"]["name"];
			 $size=($_FILES["prd_img"]["size"]/5242880)."MB<br>";
			 $type=$_FILES["prd_img"]["type"];
				$this->prd_Image=$_FILES["prd_img"]["name"];
			 move_uploaded_file($_FILES["prd_img"]["tmp_name"],"images/".$_FILES["prd_img"]["name"]);
			  
			  {echo "<script language='javascript' type='text/javascript'> alert('Image uploaded.');</script>  ";}
           
			 }
			
		
		}
	   	
		
		function SelectLastAddedPrd($prvId)
		{
			
			$query=mysql_query("select max(prd_id) from products p inner join providers prv
                                 on p.provider_id=prv.provider_id
 
                                 where prv.provider_id=$prvId ");
                                 
             $result = mysql_fetch_array($query);
           
            if($result)
               return   $result[0];
             else 
                return 0;
			
			
			
		}
				
		//Needed when updating the product 'cuz the user sent the new name, thus we can't use that name as a selector
		
	   function retrive_selected_prd_id($field)
		{
			 $query=mysql_query("select prd_id from products where prd_name= '$field';");
	
		     $result = mysql_fetch_array($query);
           
            if($result)
               return   $result[0];
             else 
                return 0;
			
			
	  	}
	  	//End of retrievin id func
		
		 function showAllProductsForCmb()
		  {
			 $query=mysql_query("select  * from products ");
	
		    
           
          return $query;
			
		}
		//End of showing product func
		
		//Used to show all the products of a specific provider when opening the page
		 function showAllProducts($ptovider_id)
		  {
			 $query=mysql_query("select  * from products p
     
                                   inner join providers prv
                                   on p.provider_id=prv.provider_id  
     
                                   where prv.provider_id=$ptovider_id");
	
		    
           
          return $query;
			
		}
		//End of showing product func
	     	
	  function retrieve_selected_prd_data($prd_id)
		{
			$sql=mysql_query("select * from products 
 
                                 where  prd_id=$prd_id");
                                 
              return $sql;
			
		} 
			//End of retrieving data func
	     	
	     	
	     	//Used to show the product data of a selected product
	    function retrieve_select_prd_data($prd_name,$provider_id)
		{
			$sql=mysql_query("select * from products p inner join providers prv
                                 on p.provider_id=prv.provider_id
 
                                 where prv.provider_id=$provider_id and p.prd_name='$prd_name'");
                                 
              return $sql;
			
		} 
			//End of retrieving data func
	     	
	     	
	     	
	     	
	    //Function to insert new product
	   	function insert_prd($name,$type,$price,$quant,$Desc,$prvd_id)
		{ 
        	$this->insert_into_img();
		    $sql="insert into products(prd_name,prd_type,prd_price,prd_qty,prd_pic,Description,provider_id)
			      values('$name','$type','$price','$quant','$this->prd_Image','$Desc','$prvd_id'); ";
            $result=mysql_query($sql);
            if($result)
              if($result)
               return true;
            else
            return  false;
			
			
		}
		//End of inserting func
	     	
	     	
	     	//Function to update the data that the user sends
	   function updat_product($prd_id,$name,$type,$price,$quant,$Desc,$prvd_id)
	    {
			$this->insert_into_img();
			
		$query=mysql_query("update products p inner join providers prv
                                 on p.provider_id=prv.provider_id
                                  set p.prd_name='$name'
                                 , p.prd_type='$type'
                                  ,p.prd_price=$price
                                  ,p.prd_qty=$quant
                                  ,p.Description='$Desc'
                                  ,p.prd_pic='$this->prd_Image'
  
                                where prv.provider_id=$prvd_id and p.prd_id=$prd_id ");
			
			
	      	
	       return $query;
		
		}
		//End of update func
	
		//Function to remove a selected products
		function Delete_product($prd_name,$provider_id)
		{
			$sql=mysql_query("Delete p FROM 
                                products p inner join providers prv
                               on p.provider_id=prv.provider_id 
                            where p.prd_name='$prd_name' and prv.provider_id=$provider_id ");
                            
              return $sql;
			
			
		}
		//End of removin'  func
		
		
		
		
		
		
		
		
	}
		
		
		
		
	
		
		
		

?>