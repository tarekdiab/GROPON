<?php
	include('./db/db.php');
	
	
	class Coupon_Object
	{
	 
	 //Function to make coupon numbers randomly
	  function generate_rand()
	  {
	   $a=mt_rand(0,9);
	   for($i=0;$i<11;$i++)
	   $a.=mt_rand(0,9);
	   
	   return $a;
		
		
	  }//End of generating random numbers
	  
	  
	  
	  //Function to add new coupons for customers
		function insert_into_coupons($customer_id,$discount_id,$coupon_validation)
		{
		   $CouponNum=$this->generate_rand();
		   $sql=mysql_query("insert into coupons(Coupon_No,discount_id,customer_id,coupon_validation,State)
			                 values('$CouponNum','$discount_id','$customer_id','$coupon_validation',0); ");
           
			
		}
		//End of adding new coupon
		
	
		    	
	  	
		function search_for_coupons($field)
		{
			$query=mysql_query("select * from 

                                (select c.Coupon_No,c.coupon_validation,c.State,u.user_name,u.phone_number
								  ,p.prd_name,p.prd_price,d.discount_name,d.disc_qty,d.no_disc_pieces
								   ,dt.disc_kind
                                  from coupons c inner join discounts d  inner join discount_types dt
                                        inner join users u inner join products p  
                                  on d.discount_id=c.discount_id  and d.discount_id=dt.discount_id
                                      and d.prd_id=p.prd_id and  c.user_id=u.user_id) temp_coup
                                   where temp_coup.Coupon_No='$field'");
                                   
                                   
          return $query;

			
		}
		
		function update_coupon_state($coupon_No)
		{
			$sql=mysql_query("update coupons 
                                 set State=true
                                 where coupon_no=$coupon_No");
                                 
			
		}
		
		//Function to delete an expired coupon
		function delete_expired_coupons($currentDate)
		{
			$sql=mysql_query("delete from
                                 coupons  
                               where  coupon_validation-$currentDate=3");
			
		}
		
	
	
	   
	      
	   
	    
	 
		
		
	}
?>