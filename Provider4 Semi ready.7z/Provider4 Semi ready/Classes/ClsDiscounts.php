<?php
	include('./db/db.php');

	
	class Discount_Object
	{
	
	
	
		//Used in index page to show all discounts of all providers
	function show_all_discounts()
	  {
		 $sql=mysql_query("select d.discount_name,d.disc_qty,d.no_disc_pieces,p.prd_name,dt.disc_kind,p.prd_pic, u.user_name,
		                      d.discount_id  
		                    from   discounts d  inner join products p inner join users u inner join  discount_types dt 
							 on d.prd_id=p.prd_id  and dt.discount_id=d.discount_id   and u.user_id=p.provider_id	 
                                    order by  d.discount_id desc " );
			                  
              return $sql;
		
		
       	}
       	//End of showing all disocunts func
       	
    
    
     //Retrieve a specific discount used whene the user select a discount 
     
	function show_selected_product($prd_id)
	  {
		 $sql=mysql_query("select  * 
		                    from   discounts d  inner join products p 
							inner join users u inner join  discount_types dt 
							 on d.prd_id=p.prd_id  and dt.discount_id=d.discount_id   
							 and u.user_id=p.provider_id	 
                        	where d.prd_id=$prd_id" );
			                  
              return $sql;
		
		
       	}
	
		
		//Used in index page to show all discounts from a specific provider
	function show_specific_discounts($Prv_id)
	  {
		 $sql=mysql_query("select d.discount_name,d.disc_qty,d.no_disc_pieces,p.prd_name,dt.disc_kind,p.prd_pic, u.user_name 
		                    d.discount_id  
		                    from   discounts d  inner join products p inner join users u inner join  discount_types dt 
							 on d.prd_id=p.prd_id  and dt.discount_id=d.discount_id   and u.user_id=p.provider_id	 
                              where p.provider_id=$Prv_id
                                order by  d.discount_id desc ");
			      
       
              return $sql;
		
		
       	}
       	//End of showing discounts of a specific provider
	
	
	
	//Used in index page to show all discounts from a specific provider
	function show_specific_prds($prd_type)
	  {
		 $sql=mysql_query("select d.discount_name,d.disc_qty,d.no_disc_pieces,p.prd_name,dt.disc_kind,p.prd_pic, u.user_name 
		                    d.discount_id  
		                    from   discounts d  inner join products p inner join users u inner join  discount_types dt 
							 on d.prd_id=p.prd_id  and dt.discount_id=d.discount_id   and u.user_id=p.provider_id	 
                              where p.prd_type'$prd_type'
                                order by  d.discount_id desc " );
			      
       
              return $sql;
		
		
       	}
       	//End of showing discounts of a specific provider
	
	
	//Inserting new discount this is done by provider only!!!!
	
	
	
		function insert_into_discount($name,$qty,$piecesCount,$prdId,$disc_kind,$provider_id)
		{
		 
		   $sql="insert into discounts(discount_name,disc_qty,no_disc_pieces,prd_id)
			      values ('$name',$qty,$piecesCount,$prdId) " ;
            $result=mysql_query($sql) or die(mysql_error());
            $LastID=$this->retrieve_last_inserted_discount($provider_id);
            $NewDiscountType=$this->insert_disc($disc_kind,$LastID);      
            return   true; 
          
			
		}
	
		
		
		
		function retrieve_last_inserted_discount($provider_id)
		{
			$sql=mysql_query("select max(discount_id) from discounts d 
			                    inner join products p inner join providers prv
								on d.prd_id=p.prd_id and p.provider_id= prv.provider_id
								where prv.provider_id=$provider_id ");
			$lastDiscountID=mysql_fetch_array($sql);
			return 	$lastDiscountID[0];				
		
		}
	   	
		
		
		
	  //Function to insert new discount type
	   	function insert_disc($disc_kind,$discount_id)
		{ 
              
		    $sql=mysql_query("insert into discount_types(disc_kind,discount_id)
			                    values('$disc_kind',$discount_id); ");
    		
		}
		
		
		//Delete discount 
		
    	function delete_disc($discount_id)
		{ 
              
		    $sql=mysql_query("insert into discount_types(disc_kind,discount_id)
			                    values('$disc_kind',$discount_id); ");
    		
		}
		
		
		//Update discounts 
		
		function update_discount($name,$qty,$piecesCount,$prdId,$disc_kind,$discount_id)
		{
		  $sql=mysql_query("update discounts d inner join discount_types dt 
                           on d.discount_id=dt.discount_id 

                         set d.discount_name='$name',
                             d.disc_qty=$qty,
                             d.no_disc_pieces=$piecesCount,
                             dt.disc_kind='$disc_kind',
                              d.prd_id=$prdId
                          where d.discount_id=$discount_id");
		}
		
		
				
		
		
	
	 
		
		
	}
?>