<?php
	include('./db/db.php');
	
	
	class Ads_Object
	{
			
		
		
	  
	     var  $Ad_Image;
	    
	 
		function insert_into_img()
		{
			if($_FILES["prd_img"])
			{
			 $tempName=$_FILES["prd_img"]["tmp_name"];
			 $orgName=$_FILES["prd_img"]["name"];
			 $size=($_FILES["prd_img"]["size"]/5242880)."MB<br>";
			 $type=$_FILES["prd_img"]["type"];
				$this->Ad_Image=$_FILES["prd_img"]["name"];
			 move_uploaded_file($_FILES["prd_img"]["tmp_name"],"Shaker/".$_FILES["prd_img"]["name"]);
			  
			  {echo "<script language='javascript' type='text/javascript'> alert('Image uploaded.');</script>  ";}
           
			 }
			
		
		}
	   	
		
		
		
		
		//Needed when updating the product 'cuz the user sent the new name, thus we can't use that name as a selector
		
	   function insert_into_Ads($AdTitle,$link,$prvd_id)
		{
			 $query=mysql_query("insert into advertisement(Title,Adver_pic,Link,Provider_id)
                                    values('$AdTitle','$this->Ad_Image','$link',$prvd_id) ");
	
		    return $query;
			
			
	  	}
	  	//End of retrievin id func
		
		
		
		 function Delete_from_Ads($AdID)
		{
			 $query=mysql_query("delete from advertisement where id=$AdID ");
	
		    return $query;
			
			
	  	}
		
		
	   function update_Ads($Ad_id,$AdTitle,$link,$prvd_id)
		{
			 $query=mysql_query("update advertisement
			                     set Title='$AdTitle',
								  Adver_pic='$this->Ad_Image',
								  Link='$link',
								  Provider_id=$prvd_id
								  where id=$Ad_id
                                    ");
	
		    return $query;
			
			
	  	}
	  	//End of retrievin id func
		
		
	  
		 function showAllAdds()
		  {
			 $query=mysql_query("select 	
                                * from advertisement");
	
		    
           
          return $query;
			
		}
		//End of showing cart func
		
		
	     	
	  
	     	
	     	
	   
		
		
		
		
	}
	
		
		
		

?>