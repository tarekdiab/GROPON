<?php
	include('./db/db.php');
	
	
	class Cart_Object
	{
			
		
		
	
		
		//Needed when updating the product 'cuz the user sent the new name, thus we can't use that name as a selector
		
	   function insert_into_cart($Coupon_id)
		{
			 $query=mysql_query("insert into cart(Coupon_id) values($Coupon_id) ");
	
		    return $query;
			
			
	  	}
	  	//End of retrievin id func
		
		 function showAlluserCarts($user_id)
		  {
			 $query=mysql_query("select 	
                                * from cart cr inner join coupons cp inner join products prd inner join discounts d 
                             on cr.coupon_id=cp.coupon_id and cp.discount_id=d.discount_id
                              and d.prd_id=prd.prd_id
                             where user_id=$user_id ");
	
		    
           
          return $query;
			
		}
		//End of showing cart func
		
		
	     	
	  
	     	
	     	
	     	
	     	
	    //Function to insert new product
	   	function delete_All_user_carts($user_id)
		{ 
        	
		    $query=mysql_query("delete cr 
                                from cart cr inner join coupons cp 
                                 on cr.coupon_id=cp.coupon_id
                               where cp.user_id=$user_id ");
	
		    
           
          return $query;
		}
		//End of inserting func
	     	
	     	
		function delete_spec_user_carts($user_id,$coupon_id)
		{ 
        	
		    $query=mysql_query("delete cr,cp 
                                from cart cr inner join coupons cp 
                                on cr.coupon_id=cp.coupon_id
                                where cp.user_id=$user_id and cp.coupon_id=$coupon_id ");
	
		    
           
          return $query;
		}
		//End of inserting func
		
		
		
		
		
	}
	
		
		
		

?>