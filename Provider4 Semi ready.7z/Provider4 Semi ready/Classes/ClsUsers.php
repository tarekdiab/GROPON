<?php
	include('./db/db.php');
	
	
	class User_object
	{
	 
	 	//Checks whether the user email exists
	   	function verify_existance($email)
		{  
		 
		 $sql=mysql_query("SELECT * FROM   users
           
                         where user_email='$email';" );
           
               return  $sql;
           
		}
		
		function ensure_provider($email)
		{
		  $sql=mysql_query(" select * from 
                            users u   inner join  providers p
                            on p.user_id=u.user_id
                            where u.user_email='$email'  ");
            
			  return  $sql;
			 
		 }
	

	  //Function to store new users
	   	function insert_users($name,$email,$pwd,$phone_num,$userType )
		 {
		  $user_data=mysql_num_rows($this->verify_existance($email));
		      if($user_data>0 )
		        {
		         
				echo 'User is already stored,please try another email address';
           
               
               }
               else
                {$sql="insert into users(user_name,user_email,user_password,phone_number,user_type)
			      values('$name','$email','$pwd','$phone_num','$userType'); ";
                 $result=mysql_query($sql);
                if($result)
                  echo 'User was successfully added';
                 }
            
          
           
			
			
		}
		
		
		function AddCashier($User_id,$provider_id)
		{
			
			$sql=mysql_query("insert into cashiers (user_id,provider_id)
			          values ( $User_id,$provider_id) ");
           
           
            return   $sql;
		}
		
		
		function DeleteCashier($Cashie_id)
		{
			
			$sql=mysql_query("delete c,u from
                                  cashiers c inner join users u
                         on u.user_id=c.user_id

                              where c.cashier_id=$Cashie_id");
           
           
            return   $sql;
		}
		
		
		
		//Select last user from usrs
		
		function retrieve_last_user()
		{
		     $query=mysql_query("select max(user_id) from users;");
	
		    $result = mysql_fetch_array($query);
             if($result)
               return   $result[0];
             else 
                return 0;
		
		}
		
	
		function insert_provider($address,$logo)
		{
	    	$last_id = $this->retrieve_last_user();
		    $sql="insert into providers(user_id,provider_address,logo)
			      values('$last_id','$address','$logo'); ";
            $result=mysql_query($sql);
          
              if($result)
               return true;
               else
            return  false;	
			
		}
		
		
		
		//Function to show all the users
		
		function show_users( )
		{ 
		    $sql="select * from users; ";
            $result=mysql_query($sql);
           
            return   $result;
		
		}
		//End of showing users 
		
		
		
	
		
		//Update users
		function update_user($user_id,$name,$email,$pwd,$phone_num)
		{
			$sql=mysql_query("update users
                           set
                            user_name ='$name',
                            user_email='$email',
                            phone_number=$phone_num,
                            user_password=$pwd ,
                            where user_id=$user_id ");
			 return $sql;
		}
		
		
	function update_provider($provider_id,$name,$email,$pwd,$phone_num,$address,$logo)
		{
			$sql=mysql_query("update users u inner join providers p
                            on u.user_id=p.user_id
                            set
                            u.user_name ='$name',
                            u.user_email='$email',
                            u.phone_number=$pwd,
                            u.user_password=$phone_num,
                            u.user_type='Provider',
                            p.provider_address='$address',
                            p.Logo='$logo'
                            where p.provider_id=$provider_id ");
                            
               return $sql;
			
		}
		
		function delete_provider($provider_id)
		{
			$sql=mysql_query("deleter u,p from 
			                  users u inner join providers p
			                  on p.user_id=u.user_id
			                  where p.provider_id=$provider_id");
			                  
			                  
	     return $sql;
			                  
			
		}
		
		
			
		//Delete cutomers
		function delete_user($user_id)
		{
			$sql=mysql_query("delete u from users u 			                              
                                     where u.user_id =$user_id ");
          	 return $sql;
		}
		
	}
?>