<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	
	
	
	

<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/prettyCheckboxes.css" type="text/css" media="all" />
	<script src="js/jquery-1.7.min.js" type="text/javascript"></script>
	<script src="js/Fly_to_cart.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/prettyCheckboxes.js" type="text/javascript"></script>
	<script src="js/DD_belatedPNG-min.js" type="text/javascript"></script>
	<script src="js/functions.js" type="text/javascript"></script>
	<script src="js/DetailsPanel.js" type="text/javascript"></script>
	<script src="js/Fly_tocart.js" type="text/javascript"></script>
     <script type='text/javascript' src="codex-fly.js"></script>
    <link rel='stylesheet' href="css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="style2.css" />
    <title> صـفحة المزود </title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Core CSS RTL-->
    <link href="css/bootstrap-rtl.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/sb-admin-rtl.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	 
    <?php  
	include('./classes/ClsDiscounts.php');
	include('./classes/ClsProducts.php');
	
	$obj_dbOpr=new Product_Object();
	$obj_disc=new Discount_Object();
	
			
	

		
		$product=$obj_dbOpr->showAllProducts(1);
		
	
		
           
       
	?>
         


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <img src="images/4.PNG"  width="200" height="230"  class="img-responsive" alt=""/>
            </div>
            <!-- Top Menu Items -->
            
            <ul class="nav top-nav navbar-right" style="margin-right: 1000px">

                <li class="dropdown nav-item">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"> طارق ذياب  <i class="fa fa-user"></i><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-user"></i> الصفحة الرئيسية</a>
                        </li>
                        
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-gear"></i> الإعدادات</a>
                        </li>
                        <li class="divider"></li>
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-power-off"></i>تسجيل الخروج</a>
                        </li>
                    </ul>
                </li>
            <ul class="nav top-nav navbar-right">
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
                
            </ul>
          <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
           <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><h4><i class="fa fa-fw fa-dashboard"></i> الصفحة الرئيسية </h4></a>
                    </li>
                    <li>
                        <a href="search coupon.php"><h4><i  class="fa fa-fw fa-search"></i>  البحث عن كوبون </h4></a>
                    </li>
                    <li>
                        <a href="upload product.php"><h4><i  class="fa fa-fw fa-upload"></i>  إضافة المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit product.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit dis.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة تخفيضات </h4> </a>
                    </li>
                    
                    <li>
                        <a href="add edv.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة أعلانات  </h4> </a>
                    </li>
                    <li>
                        <a href="Cashiers.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة محاسب   </h4> </a>
                    </li>
                    <li>
                        <a href="add Account.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل الحساب  </h4></a>
                    </li>
                    
                    
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                 <br />  <br /> 
                  
                  <br />
                
                                                                
                <div class="row">
                    <div class="col-lg-12">
                        <h1  style="color: blue ; padding-top: 10px" class="page-header">
                            تعديل المنتجات
                        </h1>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i>  صفحة تعديل المنتجات  </h3>
                            </div>
                            <div class="panel-body">
                                <br /><br />
                                
                
                   
        
		
                   <div class="col-md-3 col-sm-3 col-xs-3">
                    
                  <div class="clearfix"></div>
                 
                    <div class="x_content">
			
            <!-- احدث المنتجات -->
				
			<div class="products">
				<h2>احدث المنتجات</h2>
				<div class="raw">				
				
					<?php  	
                       
					
					     while($data=mysql_fetch_array($product))
                          {
                       ?>
                         
				<div class="product-holder">
					<div class="product">
					 <!--Show the product image in the img box-->
					 
					<a href="<?php //echo $data['Link'];?>" 
					class="hvrlink" ><img src="images/<?php echo $data['prd_pic'];?>"
					 ></a>
	
						
          
					
            
            
            <!--Details pane shows a big img and details about item retrieved from database -->
						<div class="details-pane" dir="rtl">
              <h3 class="title">تفاصيل:</h3>
              <p class="desc"></p><?php echo $data['prd_name'];?>
              <div class="big-img"><a href="<?php //echo $data['Link'];?>" target="_blank"><img src="images/1.jpg"></a></div>
            </div><!-- @end .details-pane -->
												
					</div>
					
					<div class="price-label hvr-pulse">
                    <p class="Price">تخفيضات</p> 
					<!--Show the price of the product -->
						<strike>10%</strike>
					<!--Make discount 30$ from the orignal price -->
						
					
					</div>
						<!--Assing the img from database into a local var -->
					<?php $img = $data['prd_pic']; $id = $data['prd_id']; ?>
				
					<div class="prd_options">
			        <div class="prod_details_tab"> 
			 	 <a href="javascript:void(0);" id="btn" onclick="add_to_cart('<?php echo $img; ?>');  return false;" title="header=[Gifts] body=[&nbsp;] fade=[on]" ><img src="images/cart.gif" alt="" border="0" class="left_bt hover_move"   />     
		  <form   method="POST"  action="Add Discount for a prd.php" >						  
			  <a href="Add Discount for a prd.php?id=<?php echo $id; ?>" title="header=[Specials] body=[&nbsp;] fade=[on]"><img src="images/unfav .png" onclick="ChangeMe(this);"  alt="" border="0" class="left_bt hover_move"   />	
			 	</form> 
			<form   method="POST"  action="EDIT.php" >
               
				</a> <a href="EDIT.php?id=<?php echo $id; ?>"  title="header=[Gifts] body=[&nbsp;] fade=[on]"   onclick="$(this).closest('form').submit();"><img src="images/favorites.gif" alt="" border="0" class="left_bt hover_move" /></a> 
			</form> 
			
      </div>
      
     
      
				   </div>
				    
				</div>
			             
					<!--Closing the brace of while loop -->
					<?php } ?>	
				<div class="cl"></div>
			</div>
			
			<!-- END Latest Products -->
            
        </div>
		
        
       

         

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

  
<script src="js/dropzone/dropzone.js"></script>
  
  
  
    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

    <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>      

</body>

</html>
