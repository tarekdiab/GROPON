<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
 <script type="text/javascript" src="//code.jquery.com/jquery-latest.js"></script>
    <title> صـفحة المزود </title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Core CSS RTL-->
    <link href="css/bootstrap-rtl.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/sb-admin-rtl.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    
     <link rel="stylesheet" type="text/css" href="css/PopupStyle.css" />
		<script src="js/modernizr.custom.js"></script>
    
    
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		 
		
		<link rel="stylesheet" type="text/css" href="css/PopupStyle.css" />
		<script src="js/modernizr.custom.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php
  error_reporting(E_ALL ^ E_NOTICE); 
	include('./classes/ClsProducts.php');
	$obj_dbOpr=new Product_Object();
	 include('./classes/ClsDiscounts.php');
	 include('./classes/ClsUsers.php');
	 $user_obj=new User_object();
	 
	 
	
	$obj_disc=new Discount_Object();
	
	
	
	
	
	if(@$_POST['sumit'])
	{
	    $prdname=$_POST['prd_name'];
       	$prdPrice=$_POST['prd_price'];
        $prdQty=$_POST['prd_quantity'];
        $prdtype=$_POST['prd_type'];
         @$obj_dbOpr->prd_Image=str_replace("''","''",@$_POST['prd_img']);
        $Prd_desc=$_POST['prd_desc'];
		 $Discname=$_POST['Discount_name'];
       	$DiscQuant=$_POST['disc_qty'];
        $PiecesCountPerDisc=$_POST['no_disc_pieces'];
        $Disc_kind=$_POST['disc_kind'];
        
        $res= $obj_dbOpr->insert_prd($prdname,$prdtype,$prdPrice,$prdQty,$Prd_desc,1);
		 $LastAddedPrd=$obj_dbOpr->SelectLastAddedPrd(1);
		$res=$obj_disc->insert_into_discount($Discname,$DiscQuant,$PiecesCountPerDisc,$LastAddedPrd,$Disc_kind,1);
        if($res)
           {echo "Product was inserted sucessfully";}
           else
           {echo "Wrong";}
        
	
	          	        
	        
		
		
	
    }
       
	   
	    $prodcuts=$obj_dbOpr->showAllProducts(1);
	
						        
        
    if(@$_POST['userName'])
	{
		
	   	 $Usetname=$_POST['userName'];
       	$UserEmail=$_POST['userEmail'];
        $UserPwd=$_POST['userPwd'];
        $UserPhone=$_POST['userNumber'];
		
	
         
		
		 
        $res= $user_obj->insert_users($Usetname,$UserEmail, $UserPwd,$UserPhone,'Cashier' );
	    $LastAddedUser=$user_obj->retrieve_last_user();
		$res=$user_obj->AddCashier($LastAddedUser,1);
        if($res)
           {echo "User was inserted sucessfully";}
           else
           {echo "Wrong";}
        
	 	        
	   
    
       
	} 

        
    	
    	
    	
		
	?>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
              <img src="images/4.PNG"  width="200" height="230"  class="img-responsive" alt=""/>
            </div>
            <!-- Top Menu Items -->
            
            <ul class="nav top-nav navbar-right" style="margin-right: 1000px">

                <li class="dropdown nav-item">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"> طارق ذياب  <i class="fa fa-user"></i><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-user"></i> الصفحة الرئيسية</a>
                        </li>
                        
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-gear"></i> الإعدادات</a>
                        </li>
                        <li class="divider"></li>
                        <li class="dropdown-item">
                            <a href="javascript:;"><i class="fa fa-fw fa-power-off"></i>تسجيل الخروج</a>
                        </li>
                    </ul>
                </li>
            <ul class="nav top-nav navbar-right">
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
              
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><h4><i class="fa fa-fw fa-dashboard"></i> الصفحة الرئيسية </h4></a>
                    </li>
                    <li>
                        <a href="search coupon.php"><h4><i  class="fa fa-fw fa-search"></i>  البحث عن كوبون </h4></a>
                    </li>
                    <li>
                        <a href="upload product.php"><h4><i  class="fa fa-fw fa-upload"></i> إضافة المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit product.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل المنتجات  </h4></a>
                    </li>
                    <li>
                        <a href="edit dis.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة تخفيضات </h4> </a>
                    </li>
                    
                    <li>
                        <a href="Add Discount for a prd.php"><h4><i class="fa fa-fw fa-upload"></i> أضافة أعلانات  </h4> </a>
                    </li>
                    <li>
                  <a href="javascript:void(0);" data-modal="modal-1"  class="md-trigger" ><h4><i class="fa fa-fw fa-upload"></i> أضافة محاسب   </h4> </a>
                    </li>
                    <li>
                        <a href="add Account.php"><h4><i class="fa fa-fw fa-edit"></i> تعديل الحساب  </h4></a>
                    </li>
                    
                    <li>
                
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                 <br /> 
                  <br />
                         <br /> 
                  <br />
              
                                                                
                <div class="row">
                    <div class="col-lg-12">
                        <h1  style="color: #d9534f ; padding-top: 10px" class="page-header">
                            إضافة المنتجات 
                        </h1>
                    </div>
                </div>
                <!-- /.row -->

<div class="col-sm-12">

                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><div class="card-header card-default">
                                <i class="fa fa-upload fa-fw"></i> إضافة المنتجات  
                            </div></h3>
                            </div>
                            <div class="panel-body">
                             
                          
                <div class="row">
                    <div class="col-xl-4 col-lg-12">
                        <div class="card card-default">
                            
                            <div class="card-block">
                               <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               
                    <div class="col-md-4 col-sm-4 col-xs-4">
                        
                  <div class="clearfix"></div>
                    <div class="x_content">
                         <br />
                          <br />
               
            

                 <h4> <p style="text-align: center;">قم بأضافة المنتجات الخاصة بك هنا </p></h4>
                         <br />
                 
                <form method="post" enctype="multipart/form-data" >
                  
                         
                  <input type="File"  class="dropzone" style="border: 5px solid #555555; height: 380px; width: 350px;"    name="prd_img" />
             
            
                  

                </div>
                </div>
                

                              
                        <!-- Cropping modal -->
                       

                   <div class="col-md-3 col-sm-3 col-xs-3">
                    
                  <div class="clearfix"></div>
                 
                    <div class="x_content">
                    
                    

                         <br />
                  <br />

                 <h4> <p style="text-align: center;">معلومات المنتج</p></h4>

                </div>
                
                  <br />
                      
                  <div style="border: 1px solid #555555; height: 300px; width: 250px; padding-top: 20px;"  class="col-md-12 col-sm-12 col-xs-12"   >
                <div class="form-input"><input type="text" placeholder="إســـم المنتج "  name="prd_name"  class="form-control"></div>
                <br />
               <div class="form-input"><input type="Number" placeholder=" الكمية المتوفرة من المنتج ( العدد ) " name="prd_quantity" class="form-control" ></div>
                <br />
                <div class="form-input"><input type="Number" placeholder=" سعر المنتج " class="form-control" name="prd_price"></div>
                 <br />
               
                 
                 <div class="form-input"> 
                 
                 <select name="prd_type"  >
                    					
						   <option> Clothing </option>
						   <option> Food</option>
						   <option> Electronics</option>
						
					 	
                   
                    </select>
                    
                    
                   </div>
                
            
               
                 <br /> 
                   <textarea class="form-control" rows="3" placeholder='وصــف المنتج' name="prd_desc"></textarea>
                   <br />
                     <br />
                   
                   
                </div>
               
                <div class="col-md-1 col-sm-1 col-xs-1">
                         <input type="submit" class="btn btn-primary"   name="sumit" value=" إضافة ">    </button> 
                          </div>  
                       <button type="button" data-modal="modal-1"    class="btn btn-danger md-trigger" style="margin-right: 90px">إلغاء ألأمــر </button>
           
              <br />
               <br />
                  
              
                     
               
                                                                                     
                                                                        
                </div>
                
                <br />   <br /> 
            
            
                    <div class="col-lg-4">
                        <h4> <center> إضافة تخفيض للمنتتج </h4> </center>
                        <br />
                        
                       
                          <div style="border: 1px solid #555555; height: 300px; width: 350px; padding-top: 20px;"  class="col-md-12 col-sm-12 col-xs-12"   >
                     
                <div class="form-input"><input type="text" placeholder=" إســـم  التخفيض  "  name="Discount_name"  class="form-control"></div>
                <br /><br />
               <div class="form-input"><input type="Number" placeholder=" كمية القطع " name="disc_qty" class="form-control" ></div>
                <br /><br />
                <div class="form-input"><input type="Number" placeholder=" النسبة التي سيحصل عليها او عدد القطع " class="form-control" name="no_disc_pieces""></div>
                 <br /><br />
                 <div class="form-input"><input type="text" placeholder="  نوع التخفيض "  name="disc_kind"  class="form-control"></div>
                 
                 <br /><br /><br />
             
                       
                  </form>
                
                
                
                
                <br />
                                                            
                  <div class="col-md-3 col-sm-3 col-xs-3">
                    
                  <div class="clearfix"></div>
                 
                    <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                     <div class="form-group">
                     <br /> <br /> <br /> <br />
                  <!--   <div class="col-md-3 col-sm-3 col-xs-3">
                                <label><h5> المقاسات</h5> </label>
                                	<div class="checkbox">
								<ul>       
								<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>S</label></li>
									<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>M</label></li>
									<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>L</label></li>
									<li><label class="checkbox"><input type="checkbox" name="checkbox"><i></i>XL</label></li>
								</ul>
							</div>
                            </div>
                            -->
                           	
                               
                            </div>
                            </div>
                             </div>
                            </div>
                                            
              </div>
                            
                    </div>  
                                
                            </div>
                        </div>
                    </div>
                </div>
                
                             
                             
                            </div>
                        </div>
                    </div>
                <br/>
                 <br/>
                  
                     
                                
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
	
	<!-- include<javascript>-->
   	<div class="md-modal md-effect-1" id="modal-1" dir="rtl">
    
	
    	
		
	

			<div class="md-content">
				<header class="popupHeader">
			<div class="header_title">
            <span> <label > اسم المنتج : </label> </span>
            	<select class="header_title">
                    <option>  حليب </option>
                    <option>رز</option>
            </select>
            </div>
			<span class="modal_close md-close"><i class="fa fa-times"></i></span>
		</header>
				<div>
			
                    
                    
                    <div class="user_login">
				<!-- Register Form -->
		
	
				<form method="post">
					<label>الاسم الكامل</label>
					<input type="text" placeholder=" الأسم الكامل " name="userName"/>
					<br />

					<label>البريد الالكتروني</label>
					<input type="email"   placeholder=" البريد الألكتروني " name="userEmail"/>
					<br />

					<label>كلمة المرور</label>
					<input type="password"  placeholder=" كلمة المرور " name="userPwd" />
					<br />
					<label>رقم التلفون</label>
					<input type="tel"  placeholder=" رقم التلفون " name="userNumber"/>
					<br />
						<br />

						<br />
					<div class="action_btns">
                    
						<div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> السابق</a></div>
                        
						<div class="one_half last"><a href="#" class="btn btn_red" onclick="$(this).closest('form').submit();">تسجيل</a></div>
					</div>
				</form>
			</div>

				
			</div>
					
					
				</div>
			</div>
			
		</div>

		
		<script src="js/classie.js"></script>
		<script src="js/modalEffects.js"></script>

		<!-- for the blur effect -->
		<!-- by @derSchepp https://github.com/Schepp/CSS-Filters-Polyfill -->
		<script>
			// this is important for IEs
			var polyfilter_scriptpath = '/js/';
		</script>
		<script src="js/cssParser.js"></script>
		<script src="js/css-filters-polyfill.js"></script>

<script src="js/bootstrap.min.js"></script>


    <!-- jQuery -->
    
    <script type="text/javascript">
    jQuery(document).ready(function($){
        $('.my-form .add-box').click(function(){
            var n = $('.text-box').length +1;
            if( 8 < n ) {
                alert('Stop it!');
                return false;
            }
            var box_html = $('<p class="text-box"><label for="Properties' + n + '">الخاصية</label><span> <input type="text" name="Properties[]" value="" id="box' + n + '" /> <label for="Qty_available' + n + '">الكمية المتوفرة   </span><input type="text" name="Qty_available[]" value=""  />  <a href="#" class="remove-box">Remove</a></p>');
            box_html.hide();
            $('.my-form p.text-box:last').after(box_html);
            box_html.fadeIn('slow');
            return false;
        });
        $('.my-form').on('click', '.remove-box', function(){
            $(this).parent().css( 'background-color', '#FF6C6C' );
            $(this).parent().fadeOut("slow", function() {
                $(this).remove();
                $('.box-number').each(function(index){
                    $(this).text( index + 1 );
                });
            });
            return false;
        });
    });
    </script>
  
<script src="js/dropzone/dropzone.js"></script>
   
  
  
    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

    <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>  
    
    
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    
    
    
		
		<script src="js/classie.js"></script>
		<script src="js/modalEffects.js"></script>

		<!-- for the blur effect -->
		<!-- by @derSchepp https://github.com/Schepp/CSS-Filters-Polyfill -->
		<script>
			// this is important for IEs
			var polyfilter_scriptpath = '/js/';
		</script>
		<script src="js/cssParser.js"></script>
		<script src="js/css-filters-polyfill.js"></script>
    

</body>

</html>
