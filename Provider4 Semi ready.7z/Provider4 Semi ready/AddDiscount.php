<?php
	include('./classes/ClsDiscounts.php');
	include('./classes/ClsProducts.php');
	$prd_obj=new Product_Object();
	$obj_dbOpr=new Discount_Object();
	if(@$_POST['sumit'])
	{
	    $PrdName=$_POST['prdName'];
	    $Discname=$_POST['Discount_name'];
       	$DiscQuant=$_POST['disc_qty'];
        $PiecesCountPerDisc=$_POST['no_disc_pieces'];
        $Disc_kind=$_POST['disc_kind'];
      
        
        $prd_id=$prd_obj->retrive_selected_prd_id($PrdName);
       
        
        $res= $obj_dbOpr->insert_into_discount($Discname,$DiscQuant,$PiecesCountPerDisc,$prd_id,$Disc_kind,1);
           if($res)
            {echo $res;}
           else
           {echo "Wrong";}
        
	
	          	    
	        
		
		
	
    }
       
	   
	    $Discounts=$obj_dbOpr->show_all_discounts();
        
       	$products=$prd_obj->showAllProductsForCmb();
    	
    	
    	
		
	?>

<html>

  <head> <title> PHP Image upload </title> </head>

    <body>
    
      <center><h1>PHP Uploader</h1></center>
      
        <center>
        
         <form method="post" enctype="multipart/form-data" >
            <table border="1" width="80%">
             <tr>
                    <th  width="80%"> Products Name : </th>
                        <td width="80%">
                        
                        <select name="prdName" >
                          <?php  while($prd=mysql_fetch_assoc($products))
                           {
                            ?>
        
                         <option ><?php  echo $prd['prd_name']  ;?> </option>
                         <?php } ?>
                         </select>
                       </td>
                 
                  </tr>
                  <tr>
                    <th  width="80%"> Discount Name : </th>
                        <td width="80%">
                        
                        
       
                         <input type="text" name="Discount_name" >
                        
                       </td>
                 
                  </tr>
                  
                 
                  <tr>
                  <th  width="80%"> Discount Qountity :</th>
                  
                        <td >
                        
       
                         <input type="number" name="disc_qty" />
                         
                        
                       </td>
                 
                  </tr>
                  
                 
     
                   <tr>
                    <th  width="80%"> No of pieces :</th>
                  
                        <td >
                      
       
                         <input type="number" name="no_disc_pieces" />
                         
                        
                       </td>
                 
                  </tr>
                  
                 
                  
                     
      
                    <th  width="80%"> Discount kind :</th>
                      <td >
                      
                      
                       
                        
                      
                   <input type="text"  name="disc_kind"/>
               
                         
                      
                     
                        
                       </td>
                 
                  </tr>
                  
                  
                  <tr>
                  
                   <td >
				   
				 
				   
				   </td>
                        <td >
                          <input type="submit" name="sumit" value="Add Discount" >
                        
                       </td>
                 
                  </tr>
                  
            </table>
            
            </form>
                
        </center>
        <?php 
        
         ?>
         <center> 
           <table width="80%" border="1" >
             <?php 
               $icount=1;
               while($data=mysql_fetch_array($Discounts))
               {
                ?>
                <tr>
                  <td style="text-align:center; width:10%" > <?php echo $icount; ?></td>
                   <td style="text-align:center; width:20%" > <?php echo $data[1]; ?></td>
                   
                      <td style="text-align:center; width:20%" > <?php echo $data[2]; ?></td>
                        <td style="text-align:center; width:20%" > <?php echo $data[3]; ?></td>
                         <td style="text-align:center; width:20%" > <?php echo $data[4]; ?></td>
                          <td style="text-align:center; width:20%" > <?php echo $data[5]; ?></td>
                  
               </tr> 
               <?php 
                 $icount++;
                 }
                ?>
                
                </table>
                </center>
                 <?php                  
                
                ?>
               
        
        
        
        
        
                
        </center>
        
        
        <style >
        
           .dropdown {
         position: relative;
          width: 200px;
           }
             .dropdown select
           {
              width: 100%;
           }
           .dropdown > * {
       box-sizing: border-box;
            height: 1.5em;
               }
           .dropdown select {
}
.dropdown input {
    position: absolute;
    width: calc(100% - 20px);
}
        </style>
       
    </body>
    
  

</html>